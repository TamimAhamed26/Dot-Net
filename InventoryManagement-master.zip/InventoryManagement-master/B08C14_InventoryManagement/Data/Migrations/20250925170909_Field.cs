﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace B08C14_InventoryManagement.Data.Migrations
{
    /// <inheritdoc />
    public partial class Field : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
