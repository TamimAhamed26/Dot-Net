﻿namespace B08C14_InventoryManagement.Models
{
    public class InventoryContext
    {
    }
}
